﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form3 : Form
    {
        Model1 db = new Model1();
        public Form3()
        {
            InitializeComponent();
        }
        public static Users usr { get; set; }
        private void Form3_Load(object sender, EventArgs e)
        {
            usersBindingSource.DataSource = db.Users.ToList();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 db = new Form2();
            db.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form6 db1 = new Form6();
            db1.usr = null;
            DialogResult dr = db1.ShowDialog();
            if(dr == DialogResult.OK)
            {
                usersBindingSource.DataSource = null;
                usersBindingSource.DataSource = db.Users.ToList();
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Users usr = (Users)usersBindingSource.Current;
            Form6 db2 = new Form6();
            db2.usr = usr;
            DialogResult dr = db2.ShowDialog();
            if(dr == DialogResult.OK)
            {
                usersBindingSource.DataSource = null;
                usersBindingSource.DataSource = db.Users.ToList();
            }
        }
    }
}
